"use client";

import { Bot, Clock3, Loader2, MessageCircle, Send, ShieldCheck, Sparkles, Utensils, X } from "lucide-react";
import { FormEvent, useEffect, useRef, useState } from "react";

import request from "@/lib/api";
import type { ChatResponse, Message } from "@/lib/types";

function buildWelcomeMessage(restaurantName: string, aiName: string, customWelcome?: string): Message {
  return {
    role: "assistant",
    content: customWelcome?.trim()
      || `Good evening. Welcome to ${restaurantName}. Tell me your mood, occasion, appetite, allergies, or timing, and ${aiName} will help you find the right dish, table plan, or order.`,
  };
}

export default function ChatWidget({
  slug,
  restaurantName = "Restaurant",
  aiName = "AI Maitre d'",
  welcomeMessage,
  escalationMessage = "Please call the restaurant for help.",
  primaryColor = "#c84b31",
  menuHighlights = [],
  dietaryPrompts = [],
  bottomOffsetClass = "bottom-5",
}: {
  slug?: string;
  restaurantName?: string;
  aiName?: string;
  welcomeMessage?: string;
  fallbackMessage?: string;
  escalationMessage?: string;
  primaryColor?: string;
  menuHighlights?: string[];
  dietaryPrompts?: string[];
  bottomOffsetClass?: string;
}) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>(() => [
    buildWelcomeMessage(restaurantName, aiName, welcomeMessage),
  ]);
  const [text, setText] = useState("");
  const [conversationId, setConversationId] = useState<string>();
  const [loading, setLoading] = useState(false);
  const bottom = useRef<HTMLDivElement>(null);
  const starterGroups = buildStarterGroups(menuHighlights, dietaryPrompts);

  useEffect(() => bottom.current?.scrollIntoView({ behavior: "smooth" }), [messages, loading]);

  async function send(event?: FormEvent, preset?: string) {
    event?.preventDefault();
    const message = (preset || text).trim();
    if (!message || loading) return;
    setText("");
    setMessages((current) => [...current, { role: "user", content: message }]);
    setLoading(true);
    try {
      const response = await request<ChatResponse>(slug ? `/restaurants/${slug}/chat` : "/chat", {
        method: "POST",
        body: JSON.stringify({ message, conversation_id: conversationId }),
      });
      setConversationId(response.conversation_id);
      setMessages((current) => [
        ...current,
        {
          role: "assistant",
          content: response.answer,
          is_unanswered: response.unanswered,
          sources: response.sources,
        },
      ]);
    } catch (error) {
      const rateLimited = error instanceof Error && /too many requests|rate limit|429/i.test(error.message);
      setMessages((current) => [
        ...current,
        {
          role: "assistant",
          content: rateLimited
            ? `${aiName} is taking a short pause because many guests are asking at once. Please wait a moment, or call the restaurant for urgent help.`
            : `I can't connect right now. ${escalationMessage}`,
          is_unanswered: true,
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className={`fixed inset-x-3 z-50 flex justify-end sm:left-auto sm:right-5 ${bottomOffsetClass}`}>
      {open && (
        <div className="mb-3 flex h-[min(680px,calc(100svh-7.75rem))] w-full flex-col overflow-hidden rounded-[1.5rem] border border-white/20 bg-white shadow-[0_32px_90px_rgba(0,0,0,.24)] sm:mb-4 sm:h-[min(720px,84vh)] sm:w-[min(460px,calc(100vw-2rem))] sm:rounded-[2rem]">
          <div className="relative overflow-hidden px-5 py-5 text-white" style={{ backgroundColor: primaryColor }}>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_15%_15%,rgba(255,255,255,.28),transparent_16rem),linear-gradient(135deg,rgba(0,0,0,.05),rgba(0,0,0,.28))]" />
            <div className="relative flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="grid h-12 w-12 place-items-center rounded-2xl border border-white/20 bg-white/18 shadow-lg">
                  <Bot size={22} />
                </span>
                <div>
                  <p className="font-semibold leading-tight">{restaurantName} {aiName}</p>
                  <p className="mt-1 flex items-center gap-1 text-xs text-white/80"><Sparkles size={12} /> Menu, hours, reservations</p>
                </div>
              </div>
              <button onClick={() => setOpen(false)} aria-label="Close chat" className="grid h-11 w-11 place-items-center rounded-full bg-white/15 hover:bg-white/25">
                <X size={18} />
              </button>
            </div>
            <p className="relative mt-4 rounded-2xl border border-white/15 bg-white/12 p-3 text-sm leading-6 text-white/85">
              Start with a craving, an allergy, a date-night plan, or a pickup time. I will answer from this restaurant&apos;s real menu and details.
            </p>
          </div>

          <div className="border-b bg-white px-4 py-3 text-xs leading-5 text-stone-500">
            <p className="flex items-start gap-2"><ShieldCheck size={15} className="mt-0.5 text-green-700" /> I answer only from restaurant knowledge. For allergies, please confirm with staff before ordering.</p>
          </div>

          <div className="grid grid-cols-4 border-b bg-white text-center text-[11px] font-bold text-stone-500">
            <button onClick={() => send(undefined, "Recommend a full meal for my mood tonight")} className="flex min-h-11 items-center justify-center gap-1 border-r px-2 py-3 hover:bg-stone-50">
              <Utensils size={14} /> Meal
            </button>
            <button onClick={() => send(undefined, "When are you open?")} className="flex min-h-11 items-center justify-center gap-1 border-r px-2 py-3 hover:bg-stone-50">
              <Clock3 size={14} /> Hours
            </button>
            <button onClick={() => send(undefined, "What should I know about allergies?")} className="flex min-h-11 items-center justify-center gap-1 border-r px-2 py-3 hover:bg-stone-50">
              <ShieldCheck size={14} /> Allergy
            </button>
            <button onClick={() => send(undefined, "Can I reserve a table?")} className="flex min-h-11 items-center justify-center gap-1 px-2 py-3 hover:bg-stone-50">
              <Clock3 size={14} /> Reserve
            </button>
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto bg-[#f7f3ea] p-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`max-w-[88%] rounded-2xl px-4 py-3 text-sm leading-6 shadow-sm ${
                  message.role === "user"
                    ? "ml-auto rounded-br-md text-white"
                    : message.is_unanswered
                      ? "rounded-bl-md border border-amber-100 bg-amber-50 text-amber-950"
                      : "rounded-bl-md border border-black/5 bg-white text-stone-700"
                }`}
                style={message.role === "user" ? { backgroundColor: primaryColor } : undefined}
              >
                {message.content}
                {message.role === "assistant" && message.sources && message.sources.length > 0 && (
                  <p className="mt-2 text-[11px] font-bold uppercase tracking-wider opacity-50">
                    Sources: {message.sources.join(", ")}
                  </p>
                )}
              </div>
            ))}

            {messages.length === 1 && (
              <div className="space-y-3 pt-1">
                {starterGroups.map((group) => (
                  <div key={group.label}>
                    <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-stone-500">{group.label}</p>
                    <div className="grid gap-2">
                      {group.questions.map((question) => (
                        <button
                          key={question}
                          onClick={() => send(undefined, question)}
                          disabled={loading}
                          className="min-h-11 rounded-2xl border border-black/10 bg-white px-3 py-2.5 text-left text-xs font-semibold text-stone-700 shadow-sm transition hover:-translate-y-0.5 hover:border-black/20 disabled:cursor-wait disabled:opacity-60"
                        >
                          {question}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {loading && (
              <div className="flex w-fit items-center gap-2 rounded-2xl rounded-bl-md border border-black/5 bg-white px-4 py-3 text-sm text-stone-500 shadow-sm" aria-live="polite">
                <Loader2 size={16} className="animate-spin" /> Reviewing menu, hours, and policies...
              </div>
            )}
            <div ref={bottom} />
          </div>

          <form onSubmit={(event) => send(event)} className="flex gap-2 border-t bg-white p-3">
            <input
              value={text}
              onChange={(event) => setText(event.target.value)}
              placeholder={loading ? "Checking the restaurant details..." : "Tell me your mood, allergies, occasion..."}
              className="min-h-12 min-w-0 flex-1 rounded-full border px-4 py-3 text-base outline-none focus:border-stone-500 sm:text-sm"
              disabled={loading}
            />
            <button
              className="grid h-12 w-12 shrink-0 place-items-center rounded-full text-white shadow-lg disabled:opacity-50"
              style={{ backgroundColor: primaryColor }}
              disabled={!text.trim() || loading}
              aria-label="Send message"
            >
              <Send size={18} />
            </button>
          </form>
        </div>
      )}

      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="ml-auto flex h-14 w-14 items-center justify-center rounded-full border border-white/20 text-white shadow-2xl transition hover:scale-105 hover:shadow-[0_22px_60px_rgba(0,0,0,.28)] focus:scale-105 sm:h-16 sm:w-16"
          style={{ backgroundColor: primaryColor }}
          aria-label="Open AI Maitre d'"
        >
          <MessageCircle />
        </button>
      )}
    </div>
  );
}

function buildStarterGroups(menuHighlights: string[], dietaryPrompts: string[]) {
  const highlighted = menuHighlights.slice(0, 3);
  const dishPrompts = highlighted.length > 0
    ? highlighted.map((dish) => `What pairs well with ${dish}?`)
    : ["What should I order?", "What is popular today?", "Suggest a full meal"];

  return [
    {
      label: "Recommendations",
      questions: ["I want something comforting tonight", "Plan a date-night order", ...dishPrompts].slice(0, 4),
    },
    {
      label: "Diet and allergies",
      questions: dietaryPrompts.length > 0
        ? dietaryPrompts.slice(0, 4)
        : ["What is vegetarian?", "Any gluten-free options?", "What contains nuts?", "What should I confirm for allergies?"],
    },
    {
      label: "Ordering and reservations",
      questions: ["When are you open?", "Build a pickup order for two", "Guide me before I reserve", "How does dine-in ordering work?"],
    },
  ];
}
