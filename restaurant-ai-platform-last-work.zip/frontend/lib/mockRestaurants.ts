import type { Restaurant } from "./types";

const LOCAL_FALLBACK_SLUG = "bella-napoli";
const LOCAL_FALLBACK_STATUSES = new Set([500, 502, 503, 504]);

export const localBellaNapoliRestaurant: Restaurant = {
  id: 1,
  owner_id: 1,
  theme_id: 1,
  name: "Bella Napoli",
  slug: LOCAL_FALLBACK_SLUG,
  tagline: "Wood-fired pizza, made with heart.",
  description: "A warm neighborhood pizzeria serving slow-fermented dough and Italian classics.",
  story: "Our dough rests for 48 hours and every guest is welcomed like family.",
  address: "Sonnenallee 42",
  city: "Berlin",
  postal_code: "12045",
  phone: "+49 30 123456",
  email: "ciao@bella.example",
  google_maps_url: "https://maps.example/bella",
  facebook_url: "",
  instagram_url: "https://instagram.example/bella",
  tiktok_url: "",
  opening_hours: JSON.stringify({ monday: "17:00-22:00", tuesday: "Closed" }),
  logo_url: "",
  hero_image: "https://images.example/hero.jpg",
  loading_video_url: "",
  loading_video_filename: "",
  loading_video_size_bytes: 0,
  reservation_url: "",
  primary_color: "#c84b31",
  secondary_color: "#6b7048",
  background_color: "#f7f3ea",
  text_color: "#1b1b18",
  font_family: "Cormorant Garamond",
  button_style: "pill",
  homepage_style: "editorial",
  menu_style: "cards",
  gallery_style: "grid",
  reservations_enabled: true,
  ordering_enabled: true,
  delivery_enabled: true,
  pickup_enabled: true,
  dine_in_enabled: true,
  chatbot_enabled: true,
  ai_name: "Bella AI Maitre d'",
  ai_welcome_message: "Good evening. Tell me your mood, allergies, timing, or occasion.",
  ai_tone: "Warm Italian hospitality",
  ai_allowed_topics: "Menu, allergens, opening hours, reservations, ordering, and restaurant story.",
  ai_fallback_message: "I do not have that detail yet. Please contact Bella Napoli directly.",
  ai_escalation_message: "For urgent requests, please call Bella Napoli directly.",
  ai_language: "English",
  ai_safety_instructions: "Do not invent prices, allergens, hours, or reservation availability.",
  is_published: true,
  created_at: "2026-01-01T00:00:00Z",
  theme: {
    id: 1,
    key: "italian",
    name: "Italian",
    description: "Warm Italian hospitality",
    primary_color: "#c84b31",
    secondary_color: "#6b7048",
    background_color: "#f7f3ea",
    text_color: "#1b1b18",
    font_family: "Cormorant Garamond",
    button_style: "pill",
    homepage_style: "editorial",
    menu_style: "cards",
    gallery_style: "grid",
  },
  categories: [
    {
      id: 10,
      name: "Antipasti",
      description: "Small plates to begin.",
      sort_order: 1,
      items: [
        {
          id: 101,
          category_id: 10,
          name: "Burrata Pugliese",
          description: "Creamy burrata with tomato and basil.",
          price: "11.50",
          image_url: "https://images.example/burrata.jpg",
          is_available: true,
          is_vegan: false,
          is_vegetarian: true,
          is_halal: false,
          allergens: "Milk",
        },
      ],
    },
    {
      id: 11,
      name: "Wood-fired Pizza",
      description: "Slow-fermented dough from the oven.",
      sort_order: 2,
      items: [
        {
          id: 201,
          category_id: 11,
          name: "Margherita",
          description: "Tomato, mozzarella, basil.",
          price: "12.50",
          image_url: "https://images.example/margherita.jpg",
          is_available: true,
          is_vegan: false,
          is_vegetarian: true,
          is_halal: true,
          allergens: "Gluten, Milk",
        },
        {
          id: 202,
          category_id: 11,
          name: "Truffle Bianca",
          description: "White pizza with truffle cream.",
          price: "18.00",
          image_url: "",
          is_available: false,
          is_vegan: false,
          is_vegetarian: true,
          is_halal: false,
          allergens: "Gluten, Milk",
        },
        {
          id: 203,
          category_id: 11,
          name: "Vegan Marinara",
          description: "Tomato, garlic, oregano.",
          price: "10.00",
          image_url: "",
          is_available: true,
          is_vegan: true,
          is_vegetarian: true,
          is_halal: true,
          allergens: "Gluten",
        },
      ],
    },
  ],
  images: [
    {
      id: 1,
      restaurant_id: 1,
      image_type: "gallery",
      url: "https://images.example/gallery-1.jpg",
      alt_text: "Dining room",
      sort_order: 1,
      created_at: "2026-01-01T00:00:00Z",
    },
    {
      id: 2,
      restaurant_id: 1,
      image_type: "food",
      url: "https://images.example/gallery-2.jpg",
      alt_text: "Pizza",
      sort_order: 2,
      created_at: "2026-01-01T00:00:00Z",
    },
  ],
};

export function getLocalDevelopmentRestaurantFallback(slug: string): Restaurant | null {
  if (process.env.NODE_ENV !== "development" || slug !== LOCAL_FALLBACK_SLUG) {
    return null;
  }

  return cloneRestaurant(localBellaNapoliRestaurant);
}

export function getLocalDevelopmentRestaurantFallbackForStatus(
  slug: string,
  status: number,
): Restaurant | null {
  if (!LOCAL_FALLBACK_STATUSES.has(status)) {
    return null;
  }

  return getLocalDevelopmentRestaurantFallback(slug);
}

export function getLocalDevelopmentRestaurantFallbackForError(
  slug: string,
  error: unknown,
): Restaurant | null {
  const status = statusFromError(error);

  if (status !== null) {
    return getLocalDevelopmentRestaurantFallbackForStatus(slug, status);
  }

  if (!isNetworkFetchError(error)) {
    return null;
  }

  return getLocalDevelopmentRestaurantFallback(slug);
}

function cloneRestaurant(restaurant: Restaurant): Restaurant {
  return JSON.parse(JSON.stringify(restaurant)) as Restaurant;
}

function statusFromError(error: unknown): number | null {
  if (!(error instanceof Error)) {
    return null;
  }

  const match = error.message.match(/\((\d{3})\)/);
  return match ? Number(match[1]) : null;
}

function isNetworkFetchError(error: unknown): boolean {
  if (!(error instanceof Error)) {
    return false;
  }

  return /failed to fetch|fetch failed|network|econnrefused|econnreset|connection refused/i.test(error.message);
}
